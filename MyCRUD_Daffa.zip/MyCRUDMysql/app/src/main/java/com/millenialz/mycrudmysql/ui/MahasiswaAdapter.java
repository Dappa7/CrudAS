package com.millenialz.mycrudmysql.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.millenialz.mycrudmysql.R;
import com.millenialz.mycrudmysql.data.entitas.Mahasiswa;
import com.millenialz.mycrudmysql.databinding.ListMahasiswaBinding;

import java.util.List;

public class MahasiswaAdapter extends RecyclerView.Adapter<MahasiswaAdapter.ViewHolder> {

    private final Context context;
    private final List<Mahasiswa> list;
    private final OnEditDeleteListener listener;

    public interface OnEditDeleteListener {
        void onEditClicked(Mahasiswa mhs);
        void onDeleteClicked(Mahasiswa mhs);
    }

    public MahasiswaAdapter(Context context, List<Mahasiswa> list, OnEditDeleteListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MahasiswaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ListMahasiswaBinding binding = ListMahasiswaBinding.inflate(LayoutInflater.from(context), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MahasiswaAdapter.ViewHolder holder, int position) {
        Mahasiswa data = list.get(position);
        holder.binding.tvNim.setText(data.getNim());
        holder.binding.tvNama.setText("Nama: " + data.getNama());
        holder.binding.tvJenisKelamin.setText("Jenis Kelamin: " + data.getJenisKelamin());
        holder.binding.tvJurusan.setText("Jurusan: " + data.getJurusan());
        holder.binding.tvAngkatan.setText("Angkatan: " + data.getAngkatan());

        Glide.with(context)
                .load(data.getFoto())
                .placeholder(R.drawable.baseline_image_24)
                .into(holder.binding.ivFoto);

        holder.binding.btnEdit.setOnClickListener(v -> listener.onEditClicked(data));
        holder.binding.btnDelete.setOnClickListener(v -> listener.onDeleteClicked(data));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ListMahasiswaBinding binding;
        public ViewHolder(@NonNull ListMahasiswaBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
