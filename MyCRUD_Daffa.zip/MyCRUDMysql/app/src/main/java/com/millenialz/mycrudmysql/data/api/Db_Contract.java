package com.millenialz.mycrudmysql.data.api;

public class Db_Contract {

    public static String ip = " 192.168.100.37";

    public static final String urlCreate = "http://" + ip + "/crud/api/create.php";
    public static final String urlRead   = "http://" + ip + "/crud/api/read.php";
    public static final String urlUpdate = "http://" + ip + "/crud/api/update.php";
    public static final String urlDelete = "http://" + ip + "/crud/api/delete.php";
    public static final String urlSearch = "http://" + ip + "/crud/api/search.php?nim=";
}