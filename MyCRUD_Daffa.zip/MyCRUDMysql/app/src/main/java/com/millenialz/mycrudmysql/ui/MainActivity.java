package com.millenialz.mycrudmysql.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.millenialz.mycrudmysql.R;
import com.millenialz.mycrudmysql.data.api.Db_Contract;
import com.millenialz.mycrudmysql.data.entitas.Mahasiswa;
import com.millenialz.mycrudmysql.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private List<Mahasiswa> list = new ArrayList<>();
    private MahasiswaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        binding.rvHistory.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MahasiswaAdapter(this, list, new MahasiswaAdapter.OnEditDeleteListener() {
            @Override
            public void onEditClicked(Mahasiswa mhs) {
                onEditClickedHandler(mhs);
            }

            @Override
            public void onDeleteClicked(Mahasiswa mhs) {
                onDeleteClickedHandler(mhs);
            }
        });
        binding.rvHistory.setAdapter(adapter);

        binding.btnAdd.setOnClickListener(v -> {
            startActivity(new Intent(this, AddActivity.class));
        });

        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().isEmpty()) {
                    loadData();
                } else {
                    searchData(s.toString().trim());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadData() {
        list.clear();
        StringRequest request = new StringRequest(Request.Method.GET, Db_Contract.urlRead,
                response -> {
                    try {
                        Log.d("LOAD_RESPONSE", response);
                        JSONObject json = new JSONObject(response);
                        if (json.getString("status").equals("success")) {
                            JSONArray data = json.getJSONArray("data");
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject m = data.getJSONObject(i);
                                list.add(new Mahasiswa(
                                        m.getString("nim"),
                                        m.getString("nama"),
                                        m.getString("jenis_kelamin"),
                                        m.getString("jurusan"),
                                        m.getString("angkatan"),
                                        "http://"+Db_Contract.ip+"/crud/uploads/foto_mahasiswa/" + m.getString("foto")
                                ));
                            }
                            adapter.notifyDataSetChanged();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Gagal memuat data", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }

    private void searchData(String nim) {
        list.clear();
        StringRequest request = new StringRequest(Request.Method.GET, Db_Contract.urlSearch + nim,
                response -> {
                    try {
                        Log.d("SEARCH_RESPONSE", response);
                        JSONObject json = new JSONObject(response);
                        if (json.getString("status").equals("success")) {
                            JSONObject m = json.getJSONObject("data");
                            list.add(new Mahasiswa(
                                    m.getString("nim"),
                                    m.getString("nama"),
                                    m.getString("jenis_kelamin"),
                                    m.getString("jurusan"),
                                    m.getString("angkatan"),
                                    "http://"+Db_Contract.ip+"/crud/uploads/foto_mahasiswa/" + m.getString("foto")
                            ));
                        }
                        adapter.notifyDataSetChanged();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Gagal mencari data", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }

    private void onEditClickedHandler(Mahasiswa mhs) {
        Intent intent = new Intent(this, AddActivity.class);
        intent.putExtra("edit", true);
        intent.putExtra("nim", mhs.getNim());
        intent.putExtra("nama", mhs.getNama());
        intent.putExtra("jenis_kelamin", mhs.getJenisKelamin());
        intent.putExtra("jurusan", mhs.getJurusan());
        intent.putExtra("angkatan", mhs.getAngkatan());
        intent.putExtra("foto", mhs.getFoto());
        startActivity(intent);
    }

    private void onDeleteClickedHandler(Mahasiswa mhs) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Mahasiswa")
                .setMessage("Yakin ingin menghapus " + mhs.getNama() + "?")
                .setPositiveButton("Ya", (dialog, which) -> {
                    StringRequest request = new StringRequest(Request.Method.POST, Db_Contract.urlDelete,
                            response -> {
                                loadData();
                                Toast.makeText(this, "Data dihapus", Toast.LENGTH_SHORT).show();
                            },
                            error -> Toast.makeText(this, "Gagal hapus data", Toast.LENGTH_SHORT).show()
                    ) {
                        @Override
                        protected java.util.Map<String, String> getParams() {
                            java.util.Map<String, String> params = new java.util.HashMap<>();
                            params.put("nim", mhs.getNim());
                            return params;
                        }
                    };
                    Volley.newRequestQueue(this).add(request);
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }
}