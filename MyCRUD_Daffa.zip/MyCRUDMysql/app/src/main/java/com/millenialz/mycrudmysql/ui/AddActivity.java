package com.millenialz.mycrudmysql.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.millenialz.mycrudmysql.R;
import com.millenialz.mycrudmysql.data.api.Db_Contract;
import com.millenialz.mycrudmysql.databinding.ActivityAddBinding;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AddActivity extends AppCompatActivity {

    private ActivityAddBinding binding;
    private Bitmap bitmap;
    private boolean isEdit = false;
    private String oldNim = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityAddBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        isEdit = getIntent().getBooleanExtra("edit", false);
        if (isEdit) {
            oldNim = getIntent().getStringExtra("nim");
            binding.etNim.setText(oldNim);
            binding.etNama.setText(getIntent().getStringExtra("nama"));
            binding.etJenisKelamin.setText(getIntent().getStringExtra("jenis_kelamin"));
            binding.etJurusan.setText(getIntent().getStringExtra("jurusan"));
            binding.etAngkatan.setText(getIntent().getStringExtra("angkatan"));
            binding.etNim.setEnabled(false);
        }

        binding.btnPilihFoto.setOnClickListener(v -> pickImage());
        binding.btnSimpan.setOnClickListener(v -> simpanData());
    }

    private void simpanData() {
        String url = isEdit ? Db_Contract.urlUpdate : Db_Contract.urlCreate;
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(this, isEdit ? "Berhasil update data" : "Berhasil simpan data", Toast.LENGTH_SHORT).show();
                    finish();
                },
                error -> Toast.makeText(this, "Gagal mengirim data ke server", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nim", binding.etNim.getText().toString());
                params.put("nama", binding.etNama.getText().toString());
                params.put("jenis_kelamin", binding.etJenisKelamin.getText().toString());
                params.put("jurusan", binding.etJurusan.getText().toString());
                params.put("angkatan", binding.etAngkatan.getText().toString());

                if (bitmap != null) {
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    String imgBase64 = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
                    params.put("foto", imgBase64);
                }

                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                binding.imgPreview.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}